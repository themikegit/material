import React from "react";
import {
  Page,
  Text,
  View,
  Document,
  StyleSheet,
  Image,
} from "@react-pdf/renderer";
import alp from "./ass/alp.png";

// Create styles
const styles = StyleSheet.create({
  intro: {
    display: "flex",
    alignItems: "center",
  },
  page: {
    padding: 30,
  },
  titleLeft: {
    display: "flex",
    justifyContent: "flex-start",
    padding: 5,
    fontSize: 11,
  },
  paragraph: {
    padding: 5,
    fontSize: 9,
  },
  mainPara: {
    padding: "5 , 35",
    fontSize: 10,
  },
});

export function MyDocument({ dte, br, empVal }) {
  console.log("dte", dte);
  return (
    <Document>
      <Page style={styles.page} size="A4">
        <View style={styles.intro}>
          <View>
            <Image src={alp}></Image>
            <Text style={styles.titleLeft}> BROJ UGOVORA: </Text>
          </View>
          <View>
            <Image src={alp}></Image>
            <Text style={styles.titleLeft}> BROJ UGOVORA: </Text>
          </View>
        </View>
        <View>
          <Text style={styles.paragraph}>
            {empVal.data.ime}
            Na osnovu člana 30, 31, 32, 33. i 37 Zakona o radu („Službeni
            glasnik RS“, broj 24/2005, 61/2005, 54/2009, 32/2013, 75/2014,
            13/2017-odluka US, 113/2017 I 95/2018) i člana 9 i 14 Zakona o
            agencijskom zapošljavanju („Službeni glasnik RS“, br. 86/2019), u
            Beogradu dana ugovorne strane i to: DATUM - {dte}
          </Text>
          <Text style={styles.mainPara}>
            BROJ UGOVORA - {br}
            1. ALPHA TEAM HRS d.o.o., ul. Vojvode Tankosića br. 19,
            Beograd-Vračar, koju kao ovlašćeno lice na osnovu odluke br. 425/20
            od 01.03.2020., zastupa zaposlena Nataša Milatović iz Beograda, BR.
            LICENCE: 152-02-88/2020-02 od 19.02.2020. godine (u daljem tekstu:
            POSLODAVAC)
          </Text>
        </View>
      </Page>
    </Document>
  );
}
